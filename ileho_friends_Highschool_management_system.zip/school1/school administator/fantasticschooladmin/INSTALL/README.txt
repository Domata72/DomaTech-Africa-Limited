This project was created by ronald ngoda
phone:+2540708344101
email:ronniengoda@gmail.com
website:www.ronaldngoda.rf.gd


About
========================
This is a school management system for highschools ,it has got a wide array of features including student admission,fees collection,listing of all banks for fees collection,adding teachers,adding subjects,adding classes,hostels among many other school administrative features.
You can easily use this system to manage schools with a capacity of upto 1000 students
For more customizationa and or PRO version request contact me.
For any other project regarding management and informaton systems also contact me in the above listed contacts.
You can easily manouvre through the project and view all the features and have a personalized feel with your own account.Read the instructions below to install and get started.

Installation
===========
After downloading the zip file
Extract it to the document root of your local server
Find the folder named INSTALL
in this folder find the file named fantastic_school_admin_db.sql
use this file to import the tables into your database.You can name your database as fantastic_school_admin_db
or give it any other name but make sure to make changes in the following places.First in the folder named libs,find a file named db_connect.php and edit the database name according to your preffered name,Second place is a file named config.php go and edit the database name there also and any of the details according to your local server setup

After doing all the above mentioned fundamental procedures,you can now go to your browser and run the project.You will be taken to a login page,there is no specific login credentials the project is open you can create an account and login with your own credentials.

ALL THE BEST,CHEERS!!